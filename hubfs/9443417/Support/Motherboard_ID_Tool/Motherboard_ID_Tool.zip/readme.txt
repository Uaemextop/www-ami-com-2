Overview
-------------------------------------------------------------------------------
MotherboardID Utility (MBID) attempts to display the manufacturer of your
computer motherboard.  This indicates who you should contact for BIOS support.

Note that AMI bios is typically licensed by system manufactures and configured
for their needs.  As such there is no guarantee that the bios on your platform
contains the support needed for this tool to retrive the motherboard manufac-
turer. In that even be sure to look at the "Tool Alternative" section below.

Features
-------------------------------------------------------------------------------
The utility requests DMI data from the bios to let you to verify following:

 * System manufacturer
 * Baseboard manufacturer

Requirements
-------------------------------------------------------------------------------
Supported Operating System
  MBID Utility is supported in following operating system:
   * MicrosoftR Windows(R) 7
   * MicrosoftR Windows(R) 8

Operating System Driver Requirements
  Following drivers for different operation system are required by this utility:
   * AMIFLDRV32.SYS Driver for Microsoft(R) WindowsR 32Bit Operating System.
   * AMIFLDRV64.SYS Driver for Microsoft(R) WindowsR 64Bit Operating System.

Getting Started
-------------------------------------------------------------------------------
Installation
Copy MBIDWIN.EXE, AMIFLDRV32.SYS and AMIFLDRV64.SYS to any storage location
accessible by the host system and then run MBIDWIN in Windows command prompt.
Remember that three files MUST be in same directory and that the command prompt
must be run at the Administrator level.


Usage Example
The FOllowing intructions provide one step by step example to using the MBID
tool on the Windows Operating System. 

Create a folder to execute from:
1)  Right-click on the Windows Start Button.
2)  Select "Open Windows Explorer" from the context menu.
3)  Click your root drive in the left column to select it - typically "OS(C:)"
    under "Computer"
4)  Click 'New Folder in the menu at the top of the window.
5)  Enter a folder name of "MBID_Tool".

Move the tool to the newly created folder.
6)  Locate the "MBID_Tool.zip" downloaded from www.ami.com and extract the zip.
7)  Copy the extracted zip contents into MBID_Tool folder created above.

Run the tool.
8)  Click the Windows Start button and enter "cmd" in the "Search Programs and
    Files" field, but DO NOT PRESS ENTER.
9)  Windows should list "cmd.exe" in the search results above the search box.
10) Right-click on cmd.exe and select "Run as administrator"
11) Windows User Access Control will likely prompt for authorization to run
    the command interpreter as Adminstrator. Click 'Yes' to proceed.
12) In the Windows command box that opens, change to the MBID directory using
    "CD C:\MBID_Tool <ENTER>".
13) Confirm the tool is available by typing "dir <ENTER>". Confirm that
    MBIDWIN.EXE is listed (If no, review steps 1 - 7).
14) Run the tool by typing "MBIDWIN <ENTER>"
    The tool will attempt to display the motherboard manufacturer from DMI data
    that is often embedded into the bios during manufacture.
15) Please contact the computer manufacturer listed by the tool for bios and
    motherboard technical support.

Once you have the information and no longer need MBID, simply use Windows Explorer
to click on the MBID_Tools folder you created and delete it.  There are no registry
entries or uninstall procedures needed.

Known Issues
-------------------------------------------------------------------------------
1) The tool may indicate the manufacturer as "To be filled by OEM" or something
similar.  In this case the system manufacturer string doesn't appear to be util-
ized on the platform.
2) The tool may report an error of "D7: The application is unsupported". In this
case the bios does not provide an interface that the tool requires.


Tool Alternative
-------------------------------------------------------------------------------
It is possible that the motherboard manufacturer includes DMI manufacturer data
but does not provide the necessary bios support for this tool to function.  An 
alternate way to check for the manufacturer is in the System Information data
provided by Windows.  The following steps illustrate the process:

1) Click the Windows Start ball and type "System Information" in the 'Search
Programs and files' box.
2) Look for the "System Information" program to appear in the search results (note
that you may only need to type the first few letters for Windows to locate it).
3) Click the "System Information" program search result.
4) In the right pane of the window that opens, look for "System Manufacturer"
5) The company listed to the right of "System Manufacturer" is likely the best
option for bios technical support.

Failing this, the platform/motherboard will have to be visually inspected in
order to determine the system manufacturer.



